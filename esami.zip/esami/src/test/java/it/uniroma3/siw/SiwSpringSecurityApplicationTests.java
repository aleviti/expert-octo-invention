package it.uniroma3.siw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiwSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
