package it.uniroma3.siw.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.spring.controller.validator.PazienteValidator;
import it.uniroma3.siw.spring.model.Paziente;
import it.uniroma3.siw.spring.service.PazienteService;

@Controller
public class PazienteController {
	@Autowired
	private PazienteService pazienteService;
	

    @Autowired
    private PazienteValidator pazienteValidator;

	
	
   
	
    @RequestMapping(value="/admin/paziente", method = RequestMethod.GET)
    public String addPaziente(Model model) {
    	model.addAttribute("paziente", new Paziente());
        return "admin/pazienteForm";
    }

    @RequestMapping(value = "/paziente/{id}", method = RequestMethod.GET)
    public String getPaziente(@PathVariable("id") Long id, Model model) {
    	model.addAttribute("paziente", this.pazienteService.pazientePerId(id));
    	return "paziente";
    }

    @RequestMapping(value = "/paziente", method = RequestMethod.GET)
    public String getPaziente(Model model) {
    		model.addAttribute("pazienti", this.pazienteService.tutti());
    		
    	
    		
    		return "pazienti";
    }
    
    @RequestMapping(value = "/admin/paziente", method = RequestMethod.POST)
    public String addPaziente(@ModelAttribute("paziente")Paziente paziente, 
    									Model model, BindingResult bindingResult) {
    	this.pazienteValidator.validate(paziente, bindingResult);
        if (!bindingResult.hasErrors()) {
        	this.pazienteService.inserisci(paziente);
            return "paziente";
        }
        return "admin/pazienteForm";
    }
}
