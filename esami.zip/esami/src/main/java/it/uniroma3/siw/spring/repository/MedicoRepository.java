package it.uniroma3.siw.spring.repository;

import org.springframework.data.repository.CrudRepository;


import it.uniroma3.siw.spring.model.Medico;


public interface MedicoRepository extends CrudRepository<Medico,Long> {

	Medico findByNome(String nome);



}
