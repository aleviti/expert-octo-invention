package it.uniroma3.siw.spring.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.ArrayList;
@Entity
public class Medico {
	
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;
		@Column(nullable = false,length=20)
		private String  nome;
		@Column(nullable = false,length=20)
		private String  cognome;
		@Column(nullable = false,length=20)
		private String  specializzazione;
		
		@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
		private List<Esame> esami;
		private String foto;

		 public Medico() {
		    	this.esami= new ArrayList<>();
		 }
		 public Medico(String nome,  String cognome,String specializzazione) {
		    	this();
		    	this.nome =nome ;
		    	
		    	this.cognome=cognome;
		    	this.specializzazione=specializzazione;
		    	
		    }
		

		
		
		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}
		public String getNome() {
			return nome ;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}
		public String getCognome() {
			return cognome ;
		}

		public void setCognome(String cognome) {
			this.cognome = cognome;
		}
		
		
		public String getSpecializzazione() {
			return specializzazione ;
		}

		public void setSpecializzazione(String specializzazione) {
			this.specializzazione = specializzazione;
		}
		
		public List<Esame> getEsami() {
			return esami;
		}

		public void setEsame(List<Esame> esami) {
			this.esami = esami;
		}
		public String getFoto() {
	        return foto;
	    }

	    public void setFoto(String foto) {
	        this.foto = foto;
	    }
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			
			result = prime * result + ((nome == null) ? 0 : nome.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Medico other = (Medico) obj;
			
			if (nome == null) {
				if (other.nome != null)
					return false;
			} else if (!nome.equals(other.nome))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "Medico [id=" + id + 
					"					  nome=" + nome + ", nome=" + nome + "]";
		}

		
		
		
}
