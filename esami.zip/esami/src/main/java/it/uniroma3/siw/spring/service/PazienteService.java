package it.uniroma3.siw.spring.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import it.uniroma3.siw.spring.model.Paziente;
import it.uniroma3.siw.spring.repository.PazienteRepository;

@Service
public class PazienteService {
@Autowired
private PazienteRepository pazienteRepository; 

@Transactional
public Paziente inserisci(Paziente paziente) {
	return pazienteRepository.save(paziente);
}
@Transactional
public List<Paziente> tutti() {
	return (List<Paziente>) pazienteRepository.findAll();
}



@Transactional
public Paziente pazientePerId(Long id) {
	Optional<Paziente> optional = pazienteRepository.findById(id);
	if (optional.isPresent())
		return optional.get();
	else 
		return null;
}


public Paziente findByNome(String nome) {
	return this.pazienteRepository.findByNome(nome);
}
}