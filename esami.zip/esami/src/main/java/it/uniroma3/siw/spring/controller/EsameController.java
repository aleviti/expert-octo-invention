package it.uniroma3.siw.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.spring.controller.validator.EsameValidator;

import it.uniroma3.siw.spring.model.Esame;
import it.uniroma3.siw.spring.service.EsameService;

@Controller
public class EsameController {
	@Autowired
	private EsameService esameService;
	

    @Autowired
    private EsameValidator esameValidator;

	
	
   
	
    @RequestMapping(value="/admin/esame", method = RequestMethod.GET)
    public String addEsame(Model model) {
    	model.addAttribute("esame", new Esame());
        return "admin/esameForm";
    }

    @RequestMapping(value = "/esame/{id}", method = RequestMethod.GET)
    public String getEsame(@PathVariable("id") Long id, Model model) {
    	model.addAttribute("esame", this.esameService.esamePerId(id));
    	return "esame";
    }

    @RequestMapping(value = "/esame", method = RequestMethod.GET)
    public String getEsame(Model model) {
    		model.addAttribute("esami", this.esameService.tutti());
    		
    	
    		
    		return "esami";
    }
    
    @RequestMapping(value = "/admin/esame", method = RequestMethod.POST)
    public String addEsame(@ModelAttribute("esame")Esame esame, 
    									Model model, BindingResult bindingResult) {
    	this.esameValidator.validate(esame, bindingResult);
        if (!bindingResult.hasErrors()) {
        	this.esameService.inserisci(esame);
            return "esame";
        }
        return "admin/esameForm";
    }
}
