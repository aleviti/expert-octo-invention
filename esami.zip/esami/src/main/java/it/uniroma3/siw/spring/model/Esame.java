package it.uniroma3.siw.spring.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Esame {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(nullable = false,length=20)
	private String  tipo;
	@Column(nullable = false,length=20)
	private String  nome;
	
	@Column(nullable = false,length=30)
	private String  reparto;
	@Column(nullable= false)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate data;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dataPrenotazione;
	@Column(nullable = false,length=40 )
	private Float prezzo;
	@ManyToOne (fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Medico medico;
	@ManyToOne (fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private Paziente paziente;
	 private String foto;
	public Esame() {
		
		
	}
	
	public Esame( String tipo,String nome,String reparto ,LocalDate data,LocalDate dataPrenotazione, Float prezzo) {
		this();
		
		this.tipo=tipo;
		this.nome=nome;
	    this.reparto=reparto;
		this.prezzo=prezzo;
		this.data=data;
		this.dataPrenotazione=dataPrenotazione;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getTipo() {
		return tipo ;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public String getReparto() {
		return reparto ;
	}

	public void setReparto(String reparto) {
		this.reparto = reparto;
	}
	
	public String getNome() {
		return nome ;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}
	public LocalDate getDataPrenotazione() {
		return dataPrenotazione;
	}

	public void setDataPrenotazione(LocalDate dataPrenotazione) {
		this.dataPrenotazione = dataPrenotazione;
	}
	
	public Float getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(Float prezzo) {
		this.prezzo = prezzo;
	}
	public Paziente getPaziente() {
		return paziente;
	}
	public void setPaziente(Paziente paziente) {
		this.paziente= paziente;
		
	}
	public Medico getMedico() {
		return medico;
	}
	public void setMedico(Medico medico) {
		this.medico= medico;
		
	}
	public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Esame other = (Esame) obj;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		return true;

	}
	
	
	public static List<LocalDate> getDatesBetween(LocalDate checkin, LocalDate checkout) { 
        long numOfDaysBetween = ChronoUnit.DAYS.between(checkin, checkout); 
        return IntStream.iterate(0, i -> i + 1)
                        .limit(numOfDaysBetween)
                        .mapToObj(i -> checkin.plusDays(i))
                        .collect(Collectors.toList());
    }

	@Override
	public String toString() {
		return "Esame [id=" + id + ", data=" + data +", dataPrenotazione=" + dataPrenotazione +
				 ", medico=" + medico + ", esame=" + tipo + "  ]";
	}
}
