package it.uniroma3.siw.spring.repository;

import org.springframework.data.repository.CrudRepository;


import it.uniroma3.siw.spring.model.Paziente;

public interface PazienteRepository  extends CrudRepository<Paziente,Long>{

	Paziente findByNome(String nome);

}
